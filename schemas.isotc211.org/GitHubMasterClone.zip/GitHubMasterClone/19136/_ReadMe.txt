The files in the 19136 directory have only been retained for completeness.
They SHOULD NOT BE used or REFERENCED by other XSDs.