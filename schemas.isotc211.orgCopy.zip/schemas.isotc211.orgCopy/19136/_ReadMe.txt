The files in the 19136/-1/gmw/ directory have been prepared for use with TC211 schemas
The files in the 19136/-/gml/ directory have only been retained for completeness.
     Files in 19136/-/gml/ SHOULD NOT BE used or REFERENCED by other XSDs.