pushd ../standards.iso.org/19115;zip -r 19115.zip ../*; popd
